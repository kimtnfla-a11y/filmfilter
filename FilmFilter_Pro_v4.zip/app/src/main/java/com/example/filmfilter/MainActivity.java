package com.example.filmfilter;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final int PICK = 10, CAMERA = 11;
    private static final int PREVIEW_MAX = 900, EXPORT_MAX = 2400;

    private final String[] names = {"Original","Amber","Kodak","Soft","Classic","Faded","Cool","Olive","Retro","Dream","B&W","Mono"};
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicInteger job = new AtomicInteger();

    private FrameLayout root;
    private ImageView photo;
    private TextView title, intensityLabel, hint, busyText;
    private SeekBar intensity;
    private LinearLayout filters;
    private ProgressBar progress;

    private Bitmap sourcePreview;
    private Uri sourceUri;
    private int selected = 0;
    private float strength = .78f;
    private boolean applying;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    private GradientDrawable glass(float radius, int alpha) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(alpha,255,255,255));
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), Color.argb(70,255,255,255));
        return g;
    }

    private TextView text(String s, float size, int color) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private TextView glassButton(String icon, String label) {
        TextView v = text(icon + "\n" + label, 10, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setBackground(glass(22, 34));
        v.setPadding(dp(6),dp(4),dp(6),dp(4));
        v.setContentDescription(label);
        return v;
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,9,13));

        photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackgroundColor(Color.rgb(18,19,24));
        root.addView(photo, new FrameLayout.LayoutParams(-1,-1));

        View shade = new View(this);
        shade.setBackgroundColor(Color.argb(36,0,0,0));
        root.addView(shade, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = new LinearLayout(this);
        top.setPadding(dp(16),dp(10),dp(16),dp(8));
        top.setGravity(Gravity.CENTER_VERTICAL);

        title = text("FilmFilter",20,Color.WHITE);
        title.setTypeface(null,1);
        top.addView(title,new LinearLayout.LayoutParams(0,dp(52),1));

        TextView undo = glassButton("↶","원본");
        undo.setOnClickListener(v -> reset());
        top.addView(undo,new LinearLayout.LayoutParams(dp(68),dp(52)));

        TextView save = glassButton("↓","저장");
        save.setOnClickListener(v -> export());
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(68),dp(52));
        sp.setMargins(dp(8),0,0,0); top.addView(save,sp);

        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,dp(72),Gravity.TOP);
        root.addView(top,tp);

        LinearLayout center = new LinearLayout(this);
        center.setGravity(Gravity.CENTER);
        hint=text("사진을 선택하면 필터가 시작돼요",15,Color.WHITE);
        hint.setGravity(Gravity.CENTER);
        center.addView(hint,new LinearLayout.LayoutParams(-2,dp(50)));
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,dp(80),Gravity.CENTER);
        root.addView(center,cp);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12),dp(10),dp(12),dp(10));
        panel.setBackground(glass(28,62));

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        intensityLabel=text("강도  78",12,Color.WHITE);
        row.addView(intensityLabel,new LinearLayout.LayoutParams(dp(72),dp(40)));

        intensity=new SeekBar(this); intensity.setMax(100); intensity.setProgress(78);
        row.addView(intensity,new LinearLayout.LayoutParams(0,dp(42),1));
        panel.addView(row);

        intensity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int p,boolean fromUser) {
                strength=p/100f;
                intensityLabel.setText("강도  " + p);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) { if(sourcePreview!=null) renderPreview(); }
        });

        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        filters=new LinearLayout(this);
        filters.setPadding(0,dp(7),0,dp(2));
        scroll.addView(filters);
        panel.addView(scroll,new LinearLayout.LayoutParams(-1,dp(70)));

        FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,dp(150),Gravity.BOTTOM);
        pp.setMargins(dp(10),0,dp(10),dp(10));
        root.addView(panel,pp);

        LinearLayout bottom=new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(dp(18),0,dp(18),dp(10));

        TextView gallery=glassButton("▣","갤러리");
        gallery.setOnClickListener(v -> gallery());
        bottom.addView(gallery,new LinearLayout.LayoutParams(dp(82),dp(60)));

        TextView camera=glassButton("●","카메라");
        camera.setOnClickListener(v -> camera());
        LinearLayout.LayoutParams cam=new LinearLayout.LayoutParams(dp(82),dp(60));
        cam.setMargins(dp(18),0,dp(18),0); bottom.addView(camera,cam);

        TextView reset=glassButton("↺","리셋");
        reset.setOnClickListener(v -> reset());
        bottom.addView(reset,new LinearLayout.LayoutParams(dp(82),dp(60)));

        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,dp(80),Gravity.BOTTOM);
        bp.setMargins(0,0,0,dp(154));
        root.addView(bottom,bp);

        busyText=text("",13,Color.WHITE); busyText.setGravity(Gravity.CENTER);
        busyText.setBackground(glass(18,100)); busyText.setVisibility(View.GONE);
        FrameLayout.LayoutParams bt=new FrameLayout.LayoutParams(dp(170),dp(50),Gravity.CENTER);
        root.addView(busyText,bt);

        progress=new ProgressBar(this);
        progress.setVisibility(View.GONE);
        FrameLayout.LayoutParams pr=new FrameLayout.LayoutParams(dp(34),dp(34),Gravity.CENTER);
        pr.topMargin=dp(70); root.addView(progress,pr);

        setContentView(root);
        buildFilterButtons();
    }

    private void buildFilterButtons() {
        for(int i=0;i<names.length;i++) {
            final int idx=i;
            TextView b=text(names[i],11,Color.WHITE);
            b.setGravity(Gravity.CENTER);
            b.setBackground(glass(18, idx==0?72:38));
            b.setPadding(dp(10),0,dp(10),0);
            b.setOnClickListener(v -> { selected=idx; selectVisual(idx); renderPreview(); });
            filters.addView(b,new LinearLayout.LayoutParams(dp(82),dp(52)));
            if(i<names.length-1) ((LinearLayout.LayoutParams)b.getLayoutParams()).setMargins(0,0,dp(7),0);
        }
        selectVisual(0);
    }

    private void selectVisual(int idx) {
        for(int i=0;i<filters.getChildCount();i++)
            filters.getChildAt(i).setBackground(glass(18, i==idx?86:38));
        title.setText(names[idx].equals("Original") ? "FilmFilter" : "FilmFilter  ·  "+names[idx]);
    }

    private void gallery() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK);
    }

    private void camera() {
        Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(i.resolveActivity(getPackageManager())!=null) startActivityForResult(i,CAMERA);
        else toast("카메라를 사용할 수 없어요.");
    }

    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK || data==null) return;
        if(request==PICK && data.getData()!=null) {
            sourceUri=data.getData();
            loadFromUri(sourceUri);
        } else if(request==CAMERA && data.getExtras()!=null) {
            Bitmap b=(Bitmap)data.getExtras().get("data");
            if(b!=null) setSource(b,null);
        }
    }

    private void loadFromUri(Uri uri) {
        busy("사진 불러오는 중");
        worker.execute(() -> {
            try {
                Bitmap b=decodeSample(uri,PREVIEW_MAX);
                runOnUiThread(() -> { setSource(b,uri); hideBusy(); });
            } catch(Exception e) {
                runOnUiThread(() -> { hideBusy(); toast("사진을 불러오지 못했어요."); });
            }
        });
    }

    private Bitmap decodeSample(Uri uri,int max) throws Exception {
        BitmapFactory.Options o=new BitmapFactory.Options();
        o.inJustDecodeBounds=true;
        try(InputStream in=getContentResolver().openInputStream(uri)){ BitmapFactory.decodeStream(in,null,o); }
        int sample=1, longest=Math.max(o.outWidth,o.outHeight);
        while(longest/sample>max*2) sample*=2;
        o.inJustDecodeBounds=false; o.inSampleSize=sample;
        try(InputStream in=getContentResolver().openInputStream(uri)){ return BitmapFactory.decodeStream(in,null,o); }
    }

    private void setSource(Bitmap b,Uri uri) {
        if(b==null) return;
        sourcePreview=small(b,PREVIEW_MAX);
        sourceUri=uri;
        selected=0; strength=.78f; intensity.setProgress(78);
        selectVisual(0); photo.setImageBitmap(sourcePreview);
        hint.setVisibility(View.GONE);
    }

    private Bitmap small(Bitmap b,int max) {
        int longest=Math.max(b.getWidth(),b.getHeight());
        if(longest<=max) return b;
        float s=max/(float)longest;
        return Bitmap.createScaledBitmap(b,Math.round(b.getWidth()*s),Math.round(b.getHeight()*s),true);
    }

    private void reset() {
        if(sourcePreview==null) return;
        selected=0; strength=.78f; intensity.setProgress(78);
        selectVisual(0); photo.setImageBitmap(sourcePreview);
    }

    private void renderPreview() {
        if(sourcePreview==null) { toast("먼저 사진을 선택해 주세요."); return; }
        final int my=job.incrementAndGet(), f=selected; final float a=strength;
        busy("필터 적용 중");
        worker.execute(() -> {
            Bitmap out=apply(sourcePreview,f,a);
            if(my!=job.get()) { if(out!=sourcePreview) out.recycle(); return; }
            runOnUiThread(() -> { photo.setImageBitmap(out); hideBusy(); });
        });
    }

    private Bitmap apply(Bitmap src,int f,float amount) {
        if(f==0 || amount<=0) return src;
        Bitmap out=src.copy(Bitmap.Config.ARGB_8888,true);
        int w=out.getWidth(), h=out.getHeight();
        int[] px=new int[w*h]; out.getPixels(px,0,w,0,0,w,h);
        for(int i=0;i<px.length;i++) {
            int c=px[i]; float r=Color.red(c)/255f,g=Color.green(c)/255f,b=Color.blue(c)/255f;
            float[] q=grade(r,g,b,f);
            px[i]=Color.rgb(clamp(r+(q[0]-r)*amount),clamp(g+(q[1]-g)*amount),clamp(b+(q[2]-b)*amount));
        }
        out.setPixels(px,0,w,0,0,w,h);
        return out;
    }

    private float[] grade(float r,float g,float b,int f) {
        float l=.2126f*r+.7152f*g+.0722f*b;
        switch(f) {
            case 1: return new float[]{r*1.05f+.018f,g*1.015f,b*.91f};
            case 2: return new float[]{tone(r,0.94f,0.035f),tone(g,0.98f,0.008f),tone(b,1.04f,-0.035f)};
            case 3: return new float[]{l+(r-l)*.78f+.025f,l+(g-l)*.78f+.018f,l+(b-l)*.78f+.012f};
            case 4: return new float[]{tone(r,.94f,.03f),tone(g,.96f,.02f),tone(b,.99f,.01f)};
            case 5: return new float[]{.07f+r*.86f,.07f+g*.86f,.08f+b*.86f};
            case 6: return new float[]{r*.94f,g*1.00f,b*1.08f};
            case 7: return new float[]{r*.96f,g*1.06f,b*.96f};
            case 8: return new float[]{.5f+(r-.5f)*1.10f,.5f+(g-.5f)*1.05f,.5f+(b-.5f)*.98f};
            case 9: return new float[]{r*.99f+.025f,g*.98f+.02f,b*1.04f+.03f};
            case 10: return new float[]{l,l,l};
            case 11: { float m=.08f+l*.84f; return new float[]{m,m,m}; }
            default: return new float[]{r,g,b};
        }
    }

    private float tone(float x,float contrast,float lift){ return .5f+(x-.5f)*contrast+lift; }
    private int clamp(float x){ return Math.max(0,Math.min(255,Math.round(x*255))); }

    private void export() {
        if(sourcePreview==null){ toast("먼저 사진을 선택해 주세요."); return; }
        final int my=job.incrementAndGet(), f=selected; final float a=strength;
        busy("고화질 저장 준비 중");
        worker.execute(() -> {
            try {
                Bitmap base=sourcePreview;
                if(sourceUri!=null) {
                    Bitmap full=decodeSample(sourceUri,EXPORT_MAX);
                    if(full!=null) base=full;
                }
                Bitmap out=apply(base,f,a);
                saveBitmap(out);
                if(base!=sourcePreview && !base.isRecycled()) base.recycle();
                if(out!=sourcePreview && out!=base && !out.isRecycled()) out.recycle();
                runOnUiThread(() -> { hideBusy(); toast("사진을 갤러리에 저장했어요."); });
            } catch(Exception e) {
                runOnUiThread(() -> { hideBusy(); toast("저장에 실패했어요."); });
            }
        });
    }

    private void saveBitmap(Bitmap b) throws Exception {
        String name="FilmFilter_"+System.currentTimeMillis()+".jpg";
        ContentValues v=new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME,name);
        v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
        v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/FilmFilter");
        Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
        if(uri==null) throw new Exception("MediaStore insert failed");
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            if(!b.compress(Bitmap.CompressFormat.JPEG,95,out)) throw new Exception("compress failed");
        }
    }

    private void busy(String s){ applying=true; busyText.setText(s); busyText.setVisibility(View.VISIBLE); progress.setVisibility(View.VISIBLE); }
    private void hideBusy(){ applying=false; busyText.setVisibility(View.GONE); progress.setVisibility(View.GONE); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    @Override protected void onDestroy(){
        job.incrementAndGet(); worker.shutdownNow();
        super.onDestroy();
    }
}
