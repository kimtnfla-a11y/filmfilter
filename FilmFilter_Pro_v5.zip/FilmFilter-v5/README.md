# FilmFilter v5

Android film-camera app prototype for Galaxy S25 Ultra and modern Android devices.

## Included
- CameraX in-app camera
- Front/rear camera switch
- Zoom
- Photo capture with background processing
- Video capture with CameraX VideoCapture
- Media3 Transformer GPU effects for video export
- 12 named film profiles
- Brightness / temperature / filter strength / grain / haze controls
- Gallery photo editing
- Original photo aspect ratio preserved
- High-quality JPEG/MP4 export to the FilmFilter albums
- Glass-style camera UI

The active GitHub Actions workflow can build this project with Gradle 8.11.1.
