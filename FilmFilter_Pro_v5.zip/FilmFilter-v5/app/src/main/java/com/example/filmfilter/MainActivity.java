package com.example.filmfilter;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.camera.video.FallbackStrategy;
import androidx.camera.video.FileOutputOptions;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.core.content.ContextCompat;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.effect.Brightness;
import androidx.media3.effect.Contrast;
import androidx.media3.effect.RgbAdjustment;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {
    private static final int PICK_IMAGE = 2001;
    private final ExecutorService worker = Executors.newFixedThreadPool(2);
    private final String[] FILTERS = {"SPRING","SUMMER","AUTUMN","WINTER","TREE","SEA","FLOWER","SUNSET","CAFE","FOOD","STREET","NIGHT"};
    private final int[] FILTER_COLORS = {
            0x26F5D6C8, 0x22FFD77A, 0x2CDB8A55, 0x1E93B7D8, 0x243B9B57, 0x263A9ACB,
            0x27FF8FA3, 0x32F08A4B, 0x20C58A58, 0x20E5A45B, 0x252E343A, 0x384C5270
    };

    private PreviewView previewView;
    private View tintOverlay;
    private TextView modeLabel;
    private TextView filterLabel;
    private TextView statusLabel;
    private SeekBar brightnessBar, tempBar, strengthBar, grainBar, hazeBar, zoomBar;
    private ImageCapture imageCapture;
    private VideoCapture<Recorder> videoCapture;
    private Recording recording;
    private Camera camera;
    private CameraSelector cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA;
    private int selectedFilter = 0;
    private boolean videoMode = false;
    private boolean editingGallery = false;
    private Bitmap galleryBitmap;
    private ImageView galleryPreview;
    private final ActivityResultLauncher<String[]> permissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), result -> startCamera());

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        if (hasCameraPermission()) startCamera();
        else permissionLauncher.launch(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO});
    }

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, new FrameLayout.LayoutParams(-1, -1));

        tintOverlay = new View(this);
        tintOverlay.setBackgroundColor(FILTER_COLORS[0]);
        tintOverlay.setAlpha(0.18f);
        tintOverlay.setClickable(false);
        root.addView(tintOverlay, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = glassPanel(this);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, dp(64), Gravity.TOP);
        tp.setMargins(dp(14), dp(14), dp(14), 0);
        root.addView(top, tp);

        TextView logo = text("FILMFILTER", 17, Color.WHITE);
        logo.setLetterSpacing(0.18f);
        top.addView(logo, weightParams(0, -1, 1));

        modeLabel = text("PHOTO", 11, 0xDFFFFFFF);
        modeLabel.setGravity(Gravity.CENTER);
        top.addView(modeLabel, new LinearLayout.LayoutParams(dp(72), -1));

        ImageButton gallery = iconButton("▧");
        gallery.setOnClickListener(v -> openGallery());
        top.addView(gallery, new LinearLayout.LayoutParams(dp(52), -1));

        ImageButton flip = iconButton("↻");
        flip.setOnClickListener(v -> switchCamera());
        top.addView(flip, new LinearLayout.LayoutParams(dp(52), -1));

        LinearLayout controls = glassPanel(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, dp(196), Gravity.BOTTOM);
        cp.setMargins(dp(12), 0, dp(12), dp(16));
        root.addView(controls, cp);

        HorizontalScrollView filterScroll = new HorizontalScrollView(this);
        filterScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout filterRow = new LinearLayout(this);
        filterRow.setPadding(dp(6), dp(5), dp(6), dp(5));
        filterScroll.addView(filterRow);
        controls.addView(filterScroll, new LinearLayout.LayoutParams(-1, dp(50)));
        for (int i = 0; i < FILTERS.length; i++) {
            final int index = i;
            TextView chip = text(FILTERS[i], 10, 0xF0FFFFFF);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(13), 0, dp(13), 0);
            chip.setOnClickListener(v -> selectFilter(index));
            filterRow.addView(chip, new LinearLayout.LayoutParams(-2, dp(40)));
        }

        HorizontalScrollView tuneScroll = new HorizontalScrollView(this);
        tuneScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tuneRow = new LinearLayout(this);
        tuneRow.setPadding(dp(5), 0, dp(5), 0);
        tuneScroll.addView(tuneRow);
        controls.addView(tuneScroll, new LinearLayout.LayoutParams(-1, dp(60)));
        brightnessBar = addTuner(tuneRow, "밝기", 50);
        tempBar = addTuner(tuneRow, "온도", 50);
        strengthBar = addTuner(tuneRow, "필터", 75);
        grainBar = addTuner(tuneRow, "grain", 18);
        hazeBar = addTuner(tuneRow, "haze", 14);
        zoomBar = addTuner(tuneRow, "zoom", 10);
        zoomBar.setProgress(0);
        zoomBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) { if (camera != null) camera.getCameraControl().setZoomRatio(1f + p / 10f * 4f); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        controls.addView(bottom, new LinearLayout.LayoutParams(-1, dp(76)));

        Button video = glassButton("VIDEO");
        video.setOnClickListener(v -> toggleVideoMode());
        bottom.addView(video, new LinearLayout.LayoutParams(dp(78), dp(50)));

        FrameLayout shutterWrap = new FrameLayout(this);
        bottom.addView(shutterWrap, weightParams(0, dp(76), 1));
        Button shutter = new Button(this);
        shutter.setText("●");
        shutter.setTextSize(28);
        shutter.setTextColor(Color.WHITE);
        shutter.setBackground(round(0xCCFFFFFF, 999));
        shutter.setOnClickListener(v -> shutter());
        shutterWrap.addView(shutter, centered(dp(64), dp(64)));

        Button edit = glassButton("EDIT");
        edit.setOnClickListener(v -> openGallery());
        bottom.addView(edit, new LinearLayout.LayoutParams(dp(78), dp(50)));

        statusLabel = text("READY", 10, 0xDFFFFFFF);
        statusLabel.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(dp(110), dp(28), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        sp.topMargin = dp(86);
        root.addView(statusLabel, sp);

        setContentView(root);
        bindTuneListeners();
    }

    private void bindTuneListeners() {
        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) { updateOverlay(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        };
        brightnessBar.setOnSeekBarChangeListener(l);
        tempBar.setOnSeekBarChangeListener(l);
        strengthBar.setOnSeekBarChangeListener(l);
        grainBar.setOnSeekBarChangeListener(l);
        hazeBar.setOnSeekBarChangeListener(l);
    }

    private void selectFilter(int index) {
        selectedFilter = index;
        filterLabel = modeLabel;
        filterLabel.setText(FILTERS[index]);
        updateOverlay();
    }

    private void updateOverlay() {
        if (tintOverlay == null) return;
        int base = FILTER_COLORS[selectedFilter];
        float strength = strengthBar == null ? 0.75f : strengthBar.getProgress() / 100f;
        float haze = hazeBar == null ? 0f : hazeBar.getProgress() / 100f;
        tintOverlay.setBackgroundColor(base);
        tintOverlay.setAlpha(Math.min(0.42f, 0.08f + 0.30f * strength + 0.08f * haze));
    }

    private SeekBar addTuner(LinearLayout row, String label, int defaultValue) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), 0, dp(4), 0);
        TextView t = text(label, 9, 0xDFFFFFFF);
        t.setGravity(Gravity.CENTER);
        box.addView(t, new LinearLayout.LayoutParams(dp(88), dp(20)));
        SeekBar s = new SeekBar(this);
        s.setMax(100);
        s.setProgress(defaultValue);
        box.addView(s, new LinearLayout.LayoutParams(dp(88), dp(35)));
        row.addView(box, new LinearLayout.LayoutParams(dp(96), dp(58)));
        return s;
    }

    private void startCamera() {
        if (!hasCameraPermission()) return;
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                provider.unbindAll();
                Preview preview = new Preview.Builder().build();
                imageCapture = new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build();
                Recorder recorder = new Recorder.Builder()
                        .setQualitySelector(QualitySelector.fromOrderedList(Arrays.asList(Quality.FHD, Quality.HD, Quality.SD), FallbackStrategy.higherQualityOrLowerThan(Quality.FHD)))
                        .build();
                videoCapture = VideoCapture.withOutput(recorder);
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                camera = provider.bindToLifecycle(this, cameraSelector, preview, imageCapture, videoCapture);
                if (zoomBar != null) zoomBar.setProgress(0);
            } catch (Exception e) { toast("카메라를 열 수 없습니다: " + e.getMessage()); }
        }, ContextCompat.getMainExecutor(this));
    }

    private void switchCamera() {
        cameraSelector = cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA ? CameraSelector.DEFAULT_FRONT_CAMERA : CameraSelector.DEFAULT_BACK_CAMERA;
        startCamera();
    }

    private void toggleVideoMode() {
        videoMode = !videoMode;
        modeLabel.setText(videoMode ? "VIDEO" : FILTERS[selectedFilter]);
        statusLabel.setText(videoMode ? "VIDEO READY" : "PHOTO READY");
    }

    private void shutter() {
        if (editingGallery) return;
        if (videoMode) {
            if (recording == null) startRecording(); else stopRecording();
        } else capturePhoto();
    }

    private void capturePhoto() {
        if (imageCapture == null) return;
        File raw = new File(getCacheDir(), "photo_raw_" + System.currentTimeMillis() + ".jpg");
        ImageCapture.OutputFileOptions opts = new ImageCapture.OutputFileOptions.Builder(raw).build();
        statusLabel.setText("CAPTURING…");
        imageCapture.takePicture(opts, ContextCompat.getMainExecutor(this), new ImageCapture.OnImageSavedCallback() {
            @Override public void onImageSaved(ImageCapture.OutputFileResults outputFileResults) {
                worker.execute(() -> processAndSavePhoto(raw));
            }
            @Override public void onError(ImageCaptureException exception) { statusLabel.setText("PHOTO ERROR"); toast(exception.getMessage()); }
        });
    }

    private void processAndSavePhoto(File raw) {
        Bitmap b = BitmapFactory.decodeFile(raw.getAbsolutePath());
        if (b == null) { runUi(() -> statusLabel.setText("PHOTO ERROR")); return; }
        Bitmap out = applyPhotoLook(b);
        Uri uri = saveBitmap(out);
        raw.delete();
        runUi(() -> { statusLabel.setText(uri == null ? "SAVE ERROR" : "SAVED ✓"); if (uri != null) toast("사진이 갤러리에 저장됐어요"); });
    }

    private Bitmap applyPhotoLook(Bitmap src) {
        Bitmap b = src.copy(Bitmap.Config.ARGB_8888, true);
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        float strength = strengthBar.getProgress() / 100f;
        float brightness = (brightnessBar.getProgress() - 50) / 100f;
        float temp = (tempBar.getProgress() - 50) / 100f;
        float grain = grainBar.getProgress() / 100f;
        float haze = hazeBar.getProgress() / 100f;
        Random rnd = new Random(1234L + System.currentTimeMillis());
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            float r = Color.red(c) / 255f, g = Color.green(c) / 255f, bl = Color.blue(c) / 255f;
            float[] target = filterRgb(r, g, bl, selectedFilter);
            r = lerp(r, target[0], strength); g = lerp(g, target[1], strength); bl = lerp(bl, target[2], strength);
            r += brightness; g += brightness; bl += brightness;
            r += temp * 0.055f; g += temp * 0.018f; bl -= temp * 0.055f;
            float lum = 0.2126f*r + 0.7152f*g + 0.0722f*bl;
            float contrast = 1f - haze * 0.28f;
            r = (r - 0.5f) * contrast + 0.5f + haze * 0.035f;
            g = (g - 0.5f) * contrast + 0.5f + haze * 0.035f;
            bl = (bl - 0.5f) * contrast + 0.5f + haze * 0.035f;
            float n = (rnd.nextFloat() - 0.5f) * 0.045f * grain;
            r += n; g += n; bl += n;
            px[i] = Color.argb(Color.alpha(c), clamp(r), clamp(g), clamp(bl));
        }
        b.setPixels(px, 0, w, 0, 0, w, h);
        return b;
    }

    private float[] filterRgb(float r, float g, float b, int f) {
        float rr=r, gg=g, bb=b;
        switch (f) {
            case 0: rr=r*1.02f+0.01f; gg=g*1.01f+0.01f; bb=b*0.96f+0.015f; break;
            case 1: rr=r*1.05f; gg=g*1.01f; bb=b*0.92f; break;
            case 2: rr=r*1.08f; gg=g*0.96f; bb=b*0.86f; break;
            case 3: rr=r*0.94f; gg=g*0.99f; bb=b*1.08f; break;
            case 4: rr=r*0.95f; gg=g*1.04f; bb=b*0.91f; break;
            case 5: rr=r*0.91f; gg=g*1.00f; bb=b*1.08f; break;
            case 6: rr=r*1.04f; gg=g*0.96f; bb=b*1.00f; break;
            case 7: rr=r*1.10f; gg=g*0.96f; bb=b*0.87f; break;
            case 8: rr=r*1.04f; gg=g*0.98f; bb=b*0.92f; break;
            case 9: rr=r*1.06f; gg=g*1.00f; bb=b*0.90f; break;
            case 10: rr=r*0.97f; gg=g*0.99f; bb=b*1.01f; break;
            case 11: rr=r*0.88f; gg=g*0.94f; bb=b*1.10f; break;
        }
        return new float[]{clamp(rr),clamp(gg),clamp(bb)};
    }

    private void startRecording() {
        if (videoCapture == null) return;
        File raw = new File(getCacheDir(), "video_raw_" + System.currentTimeMillis() + ".mp4");
        FileOutputOptions output = new FileOutputOptions.Builder(raw).build();
        statusLabel.setText("REC ●");
        recording = videoCapture.getOutput().prepareRecording(this, output).withAudioEnabled().start(ContextCompat.getMainExecutor(this), event -> {
            if (event instanceof VideoRecordEvent.Finalize) {
                VideoRecordEvent.Finalize fin = (VideoRecordEvent.Finalize) event;
                recording = null;
                if (fin.hasError()) { statusLabel.setText("VIDEO ERROR"); toast("동영상 녹화 실패: " + fin.getError()); raw.delete(); }
                else worker.execute(() -> transformAndSaveVideo(raw));
            }
        });
    }

    private void stopRecording() {
        if (recording != null) { statusLabel.setText("PROCESSING…"); recording.stop(); }
    }

    private void transformAndSaveVideo(File raw) {
        File out = new File(getCacheDir(), "video_filtered_" + System.currentTimeMillis() + ".mp4");
        float strength = strengthBar.getProgress() / 100f;
        float brightness = (brightnessBar.getProgress() - 50) / 100f;
        float temp = (tempBar.getProgress() - 50) / 100f;
        float haze = hazeBar.getProgress() / 100f;
        float[] rgb = videoRgb(selectedFilter, strength, temp);
        List<Effect> effects = new ArrayList<>();
        effects.add(new Brightness(brightness));
        effects.add(new Contrast(-0.10f * haze));
        effects.add(new RgbAdjustment.Builder().setRedScale(rgb[0]).setGreenScale(rgb[1]).setBlueScale(rgb[2]).build());
        EditedMediaItem item = new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(raw)))
                .setEffects(new Effects(new ArrayList<>(), effects)).build();
        Transformer transformer = new Transformer.Builder(this)
                .setVideoMimeType("video/avc")
                .addListener(new Transformer.Listener() {
                    @Override public void onCompleted(androidx.media3.transformer.Composition composition, ExportResult result) {
                        worker.execute(() -> {
                            Uri uri = saveVideo(out);
                            raw.delete(); out.delete();
                            runUi(() -> { statusLabel.setText(uri == null ? "SAVE ERROR" : "SAVED ✓"); if (uri != null) toast("필터 적용된 동영상이 저장됐어요"); });
                        });
                    }
                    @Override public void onError(androidx.media3.transformer.Composition composition, ExportResult result, ExportException exception) {
                        raw.delete(); out.delete();
                        runUi(() -> { statusLabel.setText("EXPORT ERROR"); toast("필터 처리 실패: " + exception.getMessage()); });
                    }
                }).build();
        runUi(() -> statusLabel.setText("FILTERING…"));
        transformer.start(item, out.getAbsolutePath());
    }

    private float[] videoRgb(int f, float strength, float temp) {
        float[][] bases = {
                {1.02f,1.01f,0.96f},{1.05f,1.01f,0.92f},{1.08f,0.96f,0.86f},{0.94f,0.99f,1.08f},
                {0.95f,1.04f,0.91f},{0.91f,1.00f,1.08f},{1.04f,0.96f,1.00f},{1.10f,0.96f,0.87f},
                {1.04f,0.98f,0.92f},{1.06f,1.00f,0.90f},{0.97f,0.99f,1.01f},{0.88f,0.94f,1.10f}
        };
        float[] p = bases[f];
        return new float[]{1f + (p[0]-1f)*strength + temp*0.055f, 1f + (p[1]-1f)*strength + temp*0.018f, 1f + (p[2]-1f)*strength - temp*0.055f};
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*"); intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGE || resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        editingGallery = true;
        worker.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                Bitmap b = BitmapFactory.decodeStream(in);
                galleryBitmap = b;
                runUi(() -> showGalleryEditor(b));
            } catch (Exception e) { toast("사진을 불러오지 못했어요"); }
        });
    }

    private void showGalleryEditor(Bitmap b) {
        FrameLayout root = findViewById(android.R.id.content);
        galleryPreview = new ImageView(this);
        galleryPreview.setBackgroundColor(Color.BLACK); galleryPreview.setScaleType(ImageView.ScaleType.FIT_CENTER); galleryPreview.setImageBitmap(b);
        root.addView(galleryPreview, new FrameLayout.LayoutParams(-1, -1));
        TextView done = text("SAVE", 12, Color.WHITE); done.setGravity(Gravity.CENTER); done.setBackground(round(0xB8333333, 30));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(92), dp(48), Gravity.BOTTOM|Gravity.END); p.setMargins(0,0,dp(18),dp(22)); root.addView(done,p);
        done.setOnClickListener(v -> worker.execute(() -> {
            Bitmap out = applyPhotoLook(galleryBitmap);
            Uri saved = saveBitmap(out);
            runUi(() -> { root.removeView(galleryPreview); root.removeView(done); editingGallery=false; toast(saved == null ? "저장 실패" : "편집 사진 저장 완료"); });
        }));
    }

    private Uri saveBitmap(Bitmap bitmap) {
        try {
            String name = "FilmFilter_" + System.currentTimeMillis() + ".jpg";
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues(); v.put(MediaStore.Images.Media.DISPLAY_NAME,name); v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) { v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FilmFilter"); v.put(MediaStore.Images.Media.IS_PENDING,1); }
            Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v); if(uri==null)return null;
            try(OutputStream out=cr.openOutputStream(uri)){ bitmap.compress(Bitmap.CompressFormat.JPEG,96,out); }
            if(Build.VERSION.SDK_INT>=29){v.clear();v.put(MediaStore.Images.Media.IS_PENDING,0);cr.update(uri,v,null,null);} return uri;
        } catch(Exception e){return null;}
    }

    private Uri saveVideo(File file) {
        try {
            String name = "FilmFilter_" + System.currentTimeMillis() + ".mp4";
            ContentResolver cr=getContentResolver(); ContentValues v=new ContentValues(); v.put(MediaStore.Video.Media.DISPLAY_NAME,name);v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
            if(Build.VERSION.SDK_INT>=29){v.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/FilmFilter");v.put(MediaStore.Video.Media.IS_PENDING,1);}
            Uri uri=cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v);if(uri==null)return null;
            try(InputStream in=new FileInputStream(file);OutputStream out=cr.openOutputStream(uri)){byte[]buf=new byte[1024*1024];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}
            if(Build.VERSION.SDK_INT>=29){v.clear();v.put(MediaStore.Video.Media.IS_PENDING,0);cr.update(uri,v,null,null);}return uri;
        }catch(Exception e){return null;}
    }

    private float lerp(float a,float b,float t){return a+(b-a)*t;}
    private int clamp(float x){return Math.max(0,Math.min(255,Math.round(x*255f)));}
    private void runUi(Runnable r){runOnUiThread(r);}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private Button glassButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(round(0x55333333,28));return b;}
    private ImageButton iconButton(String s){ImageButton b=new ImageButton(this);b.setImageDrawable(null);b.setContentDescription(s);b.setBackground(round(0x00000000,28));b.setOnClickListener(v->{});return b;}
    private LinearLayout glassPanel(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setPadding(dp(12),dp(5),dp(12),dp(5));l.setBackground(round(0x55333333,34));return l;}
    private android.graphics.drawable.GradientDrawable round(int color,float radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp((int)radius));d.setStroke(dp(1),0x40FFFFFF);return d;}
    private FrameLayout.LayoutParams centered(int w,int h){FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(dp(w),dp(h),Gravity.CENTER);return p;}
    private LinearLayout.LayoutParams weightParams(int w,int h,float weight){return new LinearLayout.LayoutParams(dp(w),dp(h),weight);}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
