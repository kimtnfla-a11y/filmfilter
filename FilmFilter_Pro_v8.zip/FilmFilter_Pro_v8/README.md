# FilmFilter v8

## Build matrix
- JDK / JVM target: 17
- AGP: 8.9.1
- Gradle: 8.11.1
- compileSdk / targetSdk: 36
- CameraX: 1.6.1

GitHub Actions installs Android API 36 and builds with Gradle 8.11.1.

The project includes a hardware RenderEffect preview path, CameraX photo/video capture, MediaStore source-first saving, a gallery editor, and the supplied Kodak warm/faded LUT asset.
