package com.filmfilter.v8

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import java.io.OutputStream
import java.util.concurrent.Executors

class GalleryActivity:ComponentActivity(){
 private var uri:Uri?=null;private var original:android.graphics.Bitmap?=null;private var last:android.graphics.Bitmap?=null;private val ex=Executors.newSingleThreadExecutor()
 private lateinit var image:ImageView
 private val picker=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)load(u)}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(makeUi());picker.launch("image/*")}
 private fun makeUi():LinearLayout{val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(16,40,16,16);image=ImageView(this);image.adjustViewBounds=true;image.scaleType=ImageView.ScaleType.FIT_CENTER;l.addView(image,LinearLayout.LayoutParams(-1,0,1f));val save=Button(this);save.text="SAVE";l.addView(save);save.setOnClickListener{save()};image.setOnLongClickListener{original?.let{image.setImageBitmap(it)};true};image.setOnTouchListener{_,e->if(e.action==android.view.MotionEvent.ACTION_UP)last?.let{image.setImageBitmap(it)};false};return l}
 private fun load(u:Uri){uri=u;original=contentResolver.openInputStream(u)?.use{BitmapFactory.decodeStream(it)};original?.let{image.setImageBitmap(it);apply(FilmParams())}}
 private fun apply(p:FilmParams){val b=original?:return;ex.execute{val r=FilmEngine.apply(b,p);last=r;runOnUiThread{image.setImageBitmap(r)}}}
 private fun save(){val b=last?:return;val v=android.content.ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"FilmFilter_Edit_${System.currentTimeMillis()}.jpg");put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/FilmFilter")};val u=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v)?:return;contentResolver.openOutputStream(u)?.use{b.compress(android.graphics.Bitmap.CompressFormat.JPEG,96,it)};Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show()}
}
