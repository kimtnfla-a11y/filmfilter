package com.filmfilter.v8

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class FilmParams(val strength:Float=.70f,val brightness:Float=0f,val temperature:Float=0f,val grain:Float=.18f,val haze:Float=.10f)
object FilmEngine {
    fun apply(src: Bitmap, p: FilmParams): Bitmap {
        val out=src.copy(Bitmap.Config.ARGB_8888,true); val w=out.width; val h=out.height
        val rnd=Random(1337)
        for(y in 0 until h) for(x in 0 until w){
            val c=src.getPixel(x,y); var r=Color.red(c)/255f; var g=Color.green(c)/255f; var b=Color.blue(c)/255f
            val lum=.2126f*r+.7152f*g+.0722f*b
            val skin=(r>g*1.03f && g>b*1.08f && lum>.18f && lum<.85f)
            val s=p.strength
            r=r*(1-.04f*s)+.055f*s + p.temperature*.035f*s
            g=g*(1-.035f*s)+.025f*s
            b=b*(1-.05f*s)-p.temperature*.035f*s
            val faded=0.035f*s; r=r*(1-faded)+faded*.5f; g=g*(1-faded)+faded*.5f; b=b*(1-faded)+faded*.5f
            if(!skin){ val mid=(lum-.5f)*.10f*s; r+=mid; g+=mid; b+=mid }
            r+=p.brightness; g+=p.brightness; b+=p.brightness
            if(p.haze>0){ val hz=p.haze*.07f; r=r*(1-hz)+hz*.72f; g=g*(1-hz)+hz*.70f; b=b*(1-hz)+hz*.66f }
            if(p.grain>0){ val n=(rnd.nextFloat()-.5f)*p.grain*.10f; r+=n; g+=n*.9f; b+=n*1.05f }
            out.setPixel(x,y,Color.rgb((r.coerceIn(0f,1f)*255).toInt(),(g.coerceIn(0f,1f)*255).toInt(),(b.coerceIn(0f,1f)*255).toInt()))
        }
        return out
    }
}
