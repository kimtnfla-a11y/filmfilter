package com.filmfilter.v8

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.Locale

class MainActivity: ComponentActivity() {
    private lateinit var preview: androidx.camera.view.PreviewView; private lateinit var overlay:FilterOverlayView
    private var provider:ProcessCameraProvider?=null; private var camera:Camera?=null; private var lens=CameraSelector.LENS_FACING_BACK; private var imageCapture:ImageCapture?=null; private var videoCapture:VideoCapture<Recorder>?=null; private var recording:Recording?=null
    private var isVideo=false; private var flash=ImageCapture.FLASH_MODE_AUTO; private val busy=AtomicBoolean(false); private val exec=Executors.newSingleThreadExecutor(); private var startMs=0L
    private val permission=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ startCamera() }
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main); preview=findViewById(R.id.preview); overlay=findViewById(R.id.filterOverlay); bindUi(); if(hasPerm()) startCamera() else permission.launch(arrayOf(Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO))}
    private fun hasPerm()=ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED
    private fun bindUi(){
        findViewById<TextView>(R.id.switchCamera).setOnClickListener{lens=if(lens==CameraSelector.LENS_FACING_BACK)CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK;startCamera()}
        findViewById<TextView>(R.id.flash).setOnClickListener{flash=when(flash){ImageCapture.FLASH_MODE_AUTO->ImageCapture.FLASH_MODE_ON;ImageCapture.FLASH_MODE_ON->ImageCapture.FLASH_MODE_OFF;else->ImageCapture.FLASH_MODE_AUTO};it as TextView;it.text=when(flash){ImageCapture.FLASH_MODE_ON->"ON";ImageCapture.FLASH_MODE_OFF->"OFF";else->"AUTO"}}
        findViewById<TextView>(R.id.mode).setOnClickListener{isVideo=!isVideo;(it as TextView).text=if(isVideo)"VIDEO" else "PHOTO";findViewById<TextView>(R.id.shutter).text=if(isVideo)"●" else "●"}
        findViewById<TextView>(R.id.shutter).setOnClickListener{if(isVideo)toggleVideo() else takePhoto()}
        findViewById<TextView>(R.id.gallery).setOnClickListener{startActivity(Intent(this,GalleryActivity::class.java))}
        findViewById<TextView>(R.id.zoom).setOnClickListener{setZoom(if((it as TextView).text=="1×")2f else 1f);it.text=if(it.text=="1×")"2×" else "1×"}
        findViewById<android.widget.SeekBar>(R.id.filterSeek).setOnSeekBarChangeListener(sb(0));findViewById<android.widget.SeekBar>(R.id.brightnessSeek).setOnSeekBarChangeListener(sb(1));findViewById<android.widget.SeekBar>(R.id.tempSeek).setOnSeekBarChangeListener(sb(2));findViewById<android.widget.SeekBar>(R.id.grainSeek).setOnSeekBarChangeListener(sb(3));findViewById<android.widget.SeekBar>(R.id.hazeSeek).setOnSeekBarChangeListener(sb(4))
    }
    private fun sb(which:Int)=object:android.widget.SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:android.widget.SeekBar?,v:Int,f:Boolean){when(which){0->overlay.filterStrength=v/100f;1->overlay.brightness=(v-100)/100f;2->overlay.temperature=(v-100)/100f;3->overlay.grain=v/100f;4->overlay.haze=v/100f}};override fun onStartTrackingTouch(s:android.widget.SeekBar?){};override fun onStopTrackingTouch(s:android.widget.SeekBar?) {}}
    private fun startCamera(){val f=ProcessCameraProvider.getInstance(this);f.addListener({provider=f.get();bindCamera()},ContextCompat.getMainExecutor(this))}
    private fun bindCamera(){val p=Preview.Builder().build().also{it.setSurfaceProvider(preview.surfaceProvider)};imageCapture=ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).setFlashMode(flash).build();val rec=Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD))).build();videoCapture=VideoCapture.withOutput(rec);try{provider?.unbindAll();camera=provider?.bindToLifecycle(this,CameraSelector.Builder().requireLensFacing(lens).build(),p,imageCapture,videoCapture)}catch(_:Exception){}}
    private fun setZoom(z:Float){ camera?.cameraControl?.setZoomRatio(z) }
    private fun takePhoto(){if(!busy.compareAndSet(false,true))return;val name="FilmFilter_${System.currentTimeMillis()}.jpg";val values=android.content.ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/FilmFilter")};val o=ImageCapture.OutputFileOptions.Builder(contentResolver,MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values).build();imageCapture?.takePicture(o,exec,object:ImageCapture.OnImageSavedCallback{override fun onError(e:ImageCaptureException){busy.set(false)};override fun onImageSaved(r:ImageCapture.OutputFileResults){busy.set(false)}})}
    private fun toggleVideo(){val vc=videoCapture?:return;if(recording!=null){recording?.stop();recording=null;findViewById<TextView>(R.id.timer).visibility=TextView.GONE;return};val name="FilmFilter_${System.currentTimeMillis()}.mp4";val v=android.content.ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,name);put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/FilmFilter")};val out=MediaStoreOutputOptions.Builder(contentResolver,MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(v).build();startMs=SystemClock.elapsedRealtime();recording=vc.output.prepareRecording(this,out).withAudioEnabled().start(ContextCompat.getMainExecutor(this)){e->if(e is VideoRecordEvent.Finalize){recording=null;findViewById<TextView>(R.id.timer).visibility=TextView.GONE}else if(e is VideoRecordEvent.Start){findViewById<TextView>(R.id.timer).visibility=TextView.VISIBLE}else if(e is VideoRecordEvent.Status){val sec=(SystemClock.elapsedRealtime()-startMs)/1000;findViewById<TextView>(R.id.timer).text=String.format(Locale.US,"%02d:%02d",sec/60,sec%60)}}}
    override fun onDestroy(){recording?.stop();exec.shutdown();super.onDestroy()}
}
