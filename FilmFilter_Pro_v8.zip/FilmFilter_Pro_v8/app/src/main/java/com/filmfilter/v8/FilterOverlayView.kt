package com.filmfilter.v8

import android.content.Context
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.View

class FilterOverlayView(context: Context) : View(context) {
    var filterStrength = .70f; var brightness = 0f; var temperature = 0f; var grain = .18f; var haze = .10f
        set(value) { field=value; apply() }
    init { setLayerType(View.LAYER_TYPE_HARDWARE, null); apply() }
    private fun apply() {
        if (Build.VERSION.SDK_INT < 31) return
        val s=filterStrength; val b=brightness; val t=temperature
        val sat=1f-0.10f*s
        val warmR=1f+0.08f*s+t*0.05f; val warmB=1f-0.06f*s-t*0.05f
        val m=ColorMatrix(floatArrayOf(
            sat*warmR,0f,0f,0f,8f*s+b*255f,
            0f,sat,0f,0f,2f*s+b*255f,
            0f,0f,sat*warmB,0f,-4f*s+b*255f,
            0f,0f,0f,1f,0f))
        val fade=ColorMatrix(floatArrayOf(0.96f,0f,0f,0f,7f,0f,0.96f,0f,0f,7f,0f,0f,0.96f,0f,7f,0f,0f,0f,1f,0f))
        m.postConcat(fade)
        setRenderEffect(RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(m), Shader.TileMode.CLAMP))
        alpha=1f
    }
}
