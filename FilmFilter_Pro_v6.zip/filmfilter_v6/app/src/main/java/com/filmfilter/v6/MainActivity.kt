package com.filmfilter.v6

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var capture: ImageCapture
    private lateinit var video: VideoCapture<Recorder>
    private var recording: Recording? = null
    private var lens = CameraSelector.LENS_FACING_BACK
    private var photoMode = true
    private var flash = ImageCapture.FLASH_MODE_OFF
    private var zoom = 1f
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startCamera() }

    override fun onCreate(b: Bundle?) { super.onCreate(b); buildUi(); if (hasPermissions()) startCamera() else cameraPermission.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE)) }

    private fun hasPermissions() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        root.addView(preview, FrameLayout.LayoutParams(-1,-1))
        val top = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(20,28,20,10) }
        val flashBtn=glassButton("⚡"); val flipBtn=glassButton("↻"); val galleryBtn=glassButton("▣")
        top.addView(flashBtn); top.addView(space()); top.addView(flipBtn); top.addView(space()); top.addView(galleryBtn)
        root.addView(top, FrameLayout.LayoutParams(-1,80,Gravity.TOP))
        flashBtn.setOnClickListener { flash = when(flash){ImageCapture.FLASH_MODE_OFF->ImageCapture.FLASH_MODE_ON;ImageCapture.FLASH_MODE_ON->ImageCapture.FLASH_MODE_AUTO;else->ImageCapture.FLASH_MODE_OFF}; flashBtn.text=when(flash){ImageCapture.FLASH_MODE_ON->"⚡";ImageCapture.FLASH_MODE_AUTO->"⚡A";else->"⚡̸"}; capture.flashMode=flash }
        flipBtn.setOnClickListener { lens = if(lens==CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK; startCamera() }
        galleryBtn.setOnClickListener { openGallery() }

        val mode = LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(12,0,12,0)}
        val photo=TextView(this).apply{text="PHOTO";textSize=13f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;padding=20}
        val movie=TextView(this).apply{text="VIDEO";textSize=13f;setTextColor(0x99FFFFFF.toInt());gravity=Gravity.CENTER;padding=20}
        mode.addView(photo);mode.addView(movie)
        root.addView(mode,FrameLayout.LayoutParams(-1,65,Gravity.BOTTOM).apply{bottomMargin=105})
        photo.setOnClickListener{photoMode=true;photo.setTextColor(Color.WHITE);movie.setTextColor(0x99FFFFFF.toInt())}
        movie.setOnClickListener{photoMode=false;movie.setTextColor(Color.WHITE);photo.setTextColor(0x99FFFFFF.toInt())}

        val bottom=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(22,10,22,30)}
        val zoomBtn=glassButton("1×");val shutter=TextView(this).apply{text="●";textSize=70f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setShadowLayer(8f,0f,0f,Color.BLACK)}
        bottom.addView(zoomBtn,LinearLayout.LayoutParams(80,80));bottom.addView(shutter,LinearLayout.LayoutParams(0,110,1f));bottom.addView(TextView(this),LinearLayout.LayoutParams(80,80))
        root.addView(bottom,FrameLayout.LayoutParams(-1,135,Gravity.BOTTOM))
        shutter.setOnClickListener{if(photoMode)takePhoto() else toggleVideo(shutter)}
        zoomBtn.setOnClickListener{zoom=when(zoom){1f->2f;2f->3f;else->1f};preview.camera?.cameraControl?.setZoomRatio(zoom);zoomBtn.text="${zoom.roundToInt()}×"}
        setContentView(root)
    }

    private fun space()=Space(this).apply{layoutParams=LinearLayout.LayoutParams(0,1,1f)}
    private fun glassButton(t:String)=TextView(this).apply{text=t;textSize=20f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=ColorDrawable(0x66000000);setPadding(16,0,16,0)}

    private fun startCamera(){
        val future=ProcessCameraProvider.getInstance(this);future.addListener({
            val provider=future.get(); provider.unbindAll(); val selector=CameraSelector.Builder().requireLensFacing(lens).build()
            val p=Preview.Builder().build().also{it.surfaceProvider=preview.surfaceProvider}
            capture=ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).setFlashMode(flash).build()
            val recorder=Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD))).build(); video=VideoCapture.withOutput(recorder)
            try{preview.camera=provider.bindToLifecycle(this,selector,p,capture,video)}catch(e:Exception){Toast.makeText(this,"카메라를 시작할 수 없습니다",Toast.LENGTH_SHORT).show()}
        },ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto(){ val dir=getExternalFilesDir("Pictures")!!;val file=File(dir,"FilmFilter_${System.currentTimeMillis()}.jpg");val opts=ImageCapture.OutputFileOptions.Builder(file).build();capture.takePicture(opts,executor,object:ImageCapture.OnImageSavedCallback{override fun onError(e:ImageCaptureException){runOnUiThread{Toast.makeText(this@MainActivity,"사진 저장 실패",Toast.LENGTH_SHORT).show()}};override fun onImageSaved(r:ImageCapture.OutputFileResults){runOnUiThread{Toast.makeText(this@MainActivity,"사진 저장 완료",Toast.LENGTH_SHORT).show()}}}) }

    private fun toggleVideo(button:TextView){ if(recording==null){val out=video.output.prepareRecording(this,FileOutputOptions.Builder(File(getExternalFilesDir("Movies")!!,"FilmFilter_${System.currentTimeMillis()}.mp4")).build()).apply{if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)withAudioEnabled()};recording=out.start(ContextCompat.getMainExecutor(this)){event->when(event){is VideoRecordEvent.Start->button.text="■";is VideoRecordEvent.Finalize->{recording=null;button.text="●";if(!event.hasError())Toast.makeText(this,"동영상 저장 완료",Toast.LENGTH_SHORT).show() else Toast.makeText(this,"동영상 저장 실패",Toast.LENGTH_SHORT).show()}}}} else {recording?.stop();recording=null;button.text="●"} }

    private fun openGallery(){val i=android.content.Intent(android.content.Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);startActivityForResult(i,42)}
    override fun onActivityResult(req:Int,res:Int,data:android.content.Intent?){super.onActivityResult(req,res,data);if(req==42&&res==RESULT_OK&&data?.data!=null)showEditor(data.data!!)}
    private fun showEditor(uri:Uri){val img=ImageView(this).apply{setBackgroundColor(Color.BLACK);scaleType=ImageView.ScaleType.FIT_CENTER};val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.BLACK)};root.addView(img,LinearLayout.LayoutParams(-1,0,1f));val controls=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,20)};val names=arrayOf("필터 강도","밝기","온도","Grain","Haze");val bars=names.map{SeekBar(this).apply{max=200;progress=100}};bars.forEachIndexed{i,b->controls.addView(TextView(this).apply{text=names[i];setTextColor(Color.WHITE);textSize=14f});controls.addView(b,LinearLayout.LayoutParams(-1,58));b.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){applyEditor(img,uri,bars[0].progress,bars[1].progress,bars[2].progress)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}})};val compare=Button(this).apply{text="원본 비교 (길게 누르기)"};val close=Button(this).apply{text="닫기"};controls.addView(compare);controls.addView(close);root.addView(controls,LinearLayout.LayoutParams(-1,360));setContentView(root);applyEditor(img,uri,100,100,100);compare.setOnTouchListener{_,e->if(e.action==MotionEvent.ACTION_DOWN)img.setImageURI(uri);else if(e.action==MotionEvent.ACTION_UP)applyEditor(img,uri,bars[0].progress,bars[1].progress,bars[2].progress);true};close.setOnClickListener{buildUi();startCamera()} }
    private fun applyEditor(img:ImageView,uri:Uri,strength:Int,brightness:Int,temp:Int){img.setImageURI(uri);val b=(brightness-100)/100f*40f;val t=(temp-100)/100f*25f;val s=1f+(strength-100)/100f*0.35f;val cm=ColorMatrix(floatArrayOf(s,0,0,0,b+t,0,s,0,0,b,0,0,s,0,b-t,0,0,0,1,0));img.colorFilter=ColorMatrixColorFilter(cm)}
    override fun onDestroy(){super.onDestroy();executor.shutdown()}
}
