package com.example.filmfilter;

public final class FilterPreset {
    public final String name;
    public final float exposure, temperature, tint, saturation, highlights, shadows, fade, contrast, grain, haze, halation, clarity;
    public final float r,g,b;
    public FilterPreset(String name,float exposure,float temperature,float tint,float saturation,float highlights,float shadows,float fade,float contrast,float grain,float haze,float halation,float clarity,float r,float g,float b){
        this.name=name;this.exposure=exposure;this.temperature=temperature;this.tint=tint;this.saturation=saturation;this.highlights=highlights;this.shadows=shadows;this.fade=fade;this.contrast=contrast;this.grain=grain;this.haze=haze;this.halation=halation;this.clarity=clarity;this.r=r;this.g=g;this.b=b;
    }
    public static FilterPreset[] all(){
        return new FilterPreset[]{
            new FilterPreset("SPRING",0.03f,0.08f,0.01f,0.96f,0.10f,0.06f,0.08f,0.94f,0.10f,0.03f,0.03f,-0.05f,1.02f,0.99f,0.98f),
            new FilterPreset("SUMMER",0.05f,0.04f,-0.01f,0.98f,0.14f,0.04f,0.06f,0.92f,0.09f,0.02f,0.03f,-0.05f,1.00f,1.01f,0.98f),
            new FilterPreset("AUTUMN",0.02f,0.15f,0.02f,0.94f,0.12f,0.05f,0.11f,0.93f,0.11f,0.02f,0.05f,-0.04f,1.06f,1.00f,0.94f),
            new FilterPreset("WINTER",0.01f,-0.10f,0.01f,0.90f,0.09f,0.07f,0.06f,0.97f,0.10f,0.01f,0.02f,-0.03f,0.96f,1.00f,1.05f),
            new FilterPreset("TREE",-0.01f,-0.02f,-0.01f,0.92f,0.12f,0.09f,0.07f,0.96f,0.12f,0.03f,0.03f,-0.05f,0.98f,1.02f,0.95f),
            new FilterPreset("SEA",0.04f,-0.06f,-0.02f,0.94f,0.15f,0.05f,0.08f,0.94f,0.09f,0.03f,0.02f,-0.05f,0.96f,1.00f,1.06f),
            new FilterPreset("FLOWER",0.03f,0.06f,0.03f,0.98f,0.13f,0.06f,0.09f,0.92f,0.10f,0.03f,0.04f,-0.04f,1.03f,0.99f,1.01f),
            new FilterPreset("SUNSET",0.02f,0.18f,0.00f,0.95f,0.10f,0.05f,0.12f,0.91f,0.12f,0.03f,0.07f,-0.05f,1.08f,1.00f,0.90f),
            new FilterPreset("CAFE",-0.02f,0.10f,0.01f,0.91f,0.11f,0.08f,0.13f,0.96f,0.13f,0.04f,0.04f,-0.06f,1.05f,1.01f,0.95f),
            new FilterPreset("FOOD",0.04f,0.09f,0.01f,0.97f,0.14f,0.04f,0.05f,0.91f,0.08f,0.02f,0.03f,-0.03f,1.04f,1.01f,0.95f),
            new FilterPreset("STREET",-0.01f,0.03f,0.00f,0.90f,0.09f,0.09f,0.09f,1.00f,0.14f,0.03f,0.03f,-0.06f,1.01f,1.00f,0.98f),
            new FilterPreset("NIGHT",-0.04f,-0.02f,0.01f,0.86f,0.08f,0.12f,0.07f,1.03f,0.12f,0.02f,0.02f,-0.05f,0.96f,0.99f,1.05f),
            new FilterPreset("KODAK",0.02f,0.12f,0.01f,0.93f,0.13f,0.06f,0.14f,0.92f,0.12f,0.025f,0.055f,-0.06f,1.06f,1.00f,0.93f)
        };
    }
}
