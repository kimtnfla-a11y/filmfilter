package com.example.filmfilter;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.Random;

public final class FilmFilterEngine {
    private FilmFilterEngine() {}
    public static Bitmap apply(Bitmap src, FilterPreset p, float strength, float brightness, float temperature, float grain, float haze) {
        Bitmap in = src.copy(Bitmap.Config.ARGB_8888, false);
        int w=in.getWidth(), h=in.getHeight(); int[] px=new int[w*h]; in.getPixels(px,0,w,0,0,w,h);
        Random rnd=new Random(1337L + w*31L + h);
        float s=Math.max(0f,Math.min(1.5f,strength));
        for(int y=0;y<h;y++) for(int x=0;x<w;x++) {
            int i=y*w+x, c=px[i]; float r=Color.red(c)/255f,g=Color.green(c)/255f,b=Color.blue(c)/255f;
            float lum=0.2126f*r+0.7152f*g+0.0722f*b;
            float skin=Math.max(0f,1f-Math.abs(r-g)*4f-Math.abs(g-b)*3f); skin*= (r>g && g>b ? 1f:0.35f);
            float e=brightness+p.exposure*s;
            r=exposure(r,e);g=exposure(g,e);b=exposure(b,e);
            float t=(temperature+p.temperature*s)*0.18f; r+=t; b-=t;
            float ti=p.tint*s*0.12f; g+=ti; r-=ti*0.35f; b-=ti*0.35f;
            float sat=1f+(p.saturation-1f)*s;
            r=lum+(r-lum)*sat;g=lum+(g-lum)*sat;b=lum+(b-lum)*sat;
            float hi=Math.max(0f,lum-0.55f)*p.highlights*s; r-=hi;g-=hi;b-=hi;
            float sh=Math.max(0f,0.45f-lum)*p.shadows*s; r+=sh;g+=sh;b+=sh;
            float ctr=1f+(p.contrast-1f)*s; r=(r-.5f)*ctr+.5f;g=(g-.5f)*ctr+.5f;b=(b-.5f)*ctr+.5f;
            r=r+(1f-r)*p.fade*s*0.35f;g=g+(1f-g)*p.fade*s*0.35f;b=b+(1f-b)*p.fade*s*0.35f;
            r*=1f+(p.r-1f)*s;g*=1f+(p.g-1f)*s;b*=1f+(p.b-1f)*s;
            float hz=Math.max(0f,haze+p.haze*s); r=r+(1f-r)*hz*0.16f;g=g+(1f-g)*hz*0.16f;b=b+(1f-b)*hz*0.16f;
            float grainAmt=Math.max(0f,grain+p.grain*s); float n=(rnd.nextFloat()*2f-1f)*grainAmt*0.12f;
            r+=n;g+=n*0.92f;b+=n*0.84f;
            float halo=Math.max(0f,p.halation*s)*Math.max(0f,lum-0.72f); r+=halo*0.10f;g+=halo*0.025f;b-=halo*0.02f;
            float protect=Math.min(1f,skin*0.75f); r=r*(1f-protect*0.22f)+Math.min(1f,r+0.02f)*protect*0.22f; b=b*(1f-protect*0.35f)+Math.min(1f,b+0.015f)*protect*0.35f;
            px[i]=Color.rgb(clamp(r),clamp(g),clamp(b));
        }
        in.setPixels(px,0,w,0,0,w,h); return in;
    }
    private static float exposure(float v,float e){return (float)(v*Math.pow(2.0,e));}
    private static int clamp(float v){return (int)(Math.max(0,Math.min(1,v))*255f+0.5f);}
}
