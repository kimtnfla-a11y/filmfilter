package com.example.filmfilter;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.*;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {
    private FrameLayout root; private PreviewView preview; private TextView timer; private Button shutter, mode, flip, flash, gallery;
    private boolean videoMode=false, recording=false, front=false; private int flashMode=ImageCapture.FLASH_MODE_AUTO;
    private ImageCapture imageCapture; private VideoCapture<Recorder> videoCapture; private Recording activeRecording; private long recordStart;
    private ProcessCameraProvider cameraProvider; private ExecutorService io=Executors.newSingleThreadExecutor();
    private final FilterPreset[] presets=FilterPreset.all(); private int presetIndex=0; private float filterStrength=1f, brightness=0f, temperature=0f, grain=0f, haze=0f;
    private final ActivityResultLauncher<String[]> permissionLauncher=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),r->{ if(hasCamera()) startCamera(); });
    private final ActivityResultLauncher<String> galleryLauncher=registerForActivityResult(new ActivityResultContracts.GetContent(),this::openGalleryImage);
    private final Runnable clock=()->{ if(recording){long s=(SystemClock.elapsedRealtime()-recordStart)/1000;timer.setText(String.format(Locale.US,"%02d:%02d",s/60,s%60));timer.postDelayed(clock,250);}};

    @Override public void onCreate(@Nullable Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.BLACK); buildUi(); if(!hasCamera()) permissionLauncher.launch(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_MEDIA_IMAGES,Manifest.permission.READ_MEDIA_VIDEO}); else startCamera();}
    private boolean hasCamera(){return ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED;}
    private void buildUi(){
        root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK); preview=new PreviewView(this); preview.setImplementationMode(PreviewView.ImplementationMode.PERFORMANCE); preview.setScaleType(PreviewView.ScaleType.FILL_CENTER); root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(24,18,24,12); addTop(top); FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,80,Gravity.TOP); root.addView(top,tp);
        timer=label("00:00",14); timer.setVisibility(View.GONE); FrameLayout.LayoutParams tm=new FrameLayout.LayoutParams(-2,60,Gravity.TOP|Gravity.CENTER_HORIZONTAL);tm.topMargin=88;root.addView(timer,tm);
        LinearLayout bottom=new LinearLayout(this); bottom.setOrientation(LinearLayout.VERTICAL); bottom.setGravity(Gravity.CENTER); bottom.setPadding(20,8,20,24); addBottom(bottom); FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,300,Gravity.BOTTOM);root.addView(bottom,bp);
        setContentView(root);
    }
    private void addTop(LinearLayout top){
        flash=glassButton("AUTO"); flip=glassButton("↺"); gallery=glassButton("▣"); Space sp=new Space(this);top.addView(flash,weight(1));top.addView(sp,weight(.8f));top.addView(gallery,weight(1));top.addView(flip,weight(1));
        flash.setOnClickListener(v->{flashMode=flashMode==ImageCapture.FLASH_MODE_AUTO?ImageCapture.FLASH_MODE_ON:flashMode==ImageCapture.FLASH_MODE_ON?ImageCapture.FLASH_MODE_OFF:ImageCapture.FLASH_MODE_AUTO;flash.setText(flashMode==ImageCapture.FLASH_MODE_AUTO?"AUTO":flashMode==ImageCapture.FLASH_MODE_ON?"ON":"OFF");});
        flip.setOnClickListener(v->{front=!front;startCamera();}); gallery.setOnClickListener(v->galleryLauncher.launch("image/*"));
    }
    private void addBottom(LinearLayout b){
        LinearLayout modes=new LinearLayout(this);modes.setGravity(Gravity.CENTER); mode=glassButton("PHOTO");Button vid=glassButton("VIDEO");modes.addView(mode);modes.addView(vid);b.addView(modes,new LinearLayout.LayoutParams(-1,55));
        vid.setOnClickListener(v->{videoMode=true;mode.setText("VIDEO");vid.setText("PHOTO");}); mode.setOnClickListener(v->{videoMode=!videoMode;mode.setText(videoMode?"VIDEO":"PHOTO");vid.setText(videoMode?"PHOTO":"VIDEO");});
        LinearLayout filters=new LinearLayout(this);filters.setGravity(Gravity.CENTER);ScrollView sv=new ScrollView(this);sv.setHorizontalScrollBarEnabled(false);sv.addView(filters);b.addView(sv,new LinearLayout.LayoutParams(-1,58));
        for(int i=0;i<presets.length-1;i++){final int idx=i;Button f=glassButton(presets[i].name);f.setTextSize(10);f.setOnClickListener(v->{presetIndex=idx;});filters.addView(f,new LinearLayout.LayoutParams(90,50));}
        shutter=new Button(this);shutter.setText("●");shutter.setTextSize(30);shutter.setTextColor(Color.WHITE);GradientDrawable gd=new GradientDrawable();gd.setShape(GradientDrawable.OVAL);gd.setColor(Color.argb(210,255,255,255));shutter.setBackground(gd);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(92,92);sp.gravity=Gravity.CENTER;sp.topMargin=10;b.addView(shutter,sp);shutter.setOnClickListener(v->{if(videoMode)toggleVideo();else takePhoto();});
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);addSlider(controls,"F",0,150,100,(v)->filterStrength=v/100f);addSlider(controls,"B",-50,50,0,(v)->brightness=v/100f);addSlider(controls,"T",-50,50,0,(v)->temperature=v/100f);addSlider(controls,"G",0,100,0,(v)->grain=v/100f);addSlider(controls,"H",0,100,0,(v)->haze=v/100f);b.addView(controls,new LinearLayout.LayoutParams(-1,90));
    }
    private void addSlider(LinearLayout parent,String title,int min,int max,int val,android.widget.SeekBar.OnSeekBarChangeListener l){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);TextView t=label(title,10);box.addView(t);SeekBar s=new SeekBar(this);s.setMax(max-min);s.setProgress(val-min);s.setOnSeekBarChangeListener(l);box.addView(s,new LinearLayout.LayoutParams(120,45));parent.addView(box,new LinearLayout.LayoutParams(0,80,1));}
    private Button glassButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);GradientDrawable g=new GradientDrawable();g.setColor(Color.argb(90,30,30,30));g.setCornerRadius(24);g.setStroke(1,Color.argb(100,255,255,255));b.setBackground(g);return b;}
    private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setGravity(Gravity.CENTER);return t;}
    private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,-1,w);}

    private void startCamera(){final ListenableFuture<ProcessCameraProvider> f=ProcessCameraProvider.getInstance(this);f.addListener(()->{try{cameraProvider=f.get();bindCamera();}catch(Exception e){toast("카메라를 시작할 수 없습니다");}},ContextCompat.getMainExecutor(this));}
    private void bindCamera(){cameraProvider.unbindAll();Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());CameraSelector sel=new CameraSelector.Builder().requireLensFacing(front?CameraSelector.LENS_FACING_FRONT:CameraSelector.LENS_FACING_BACK).build();imageCapture=new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build();Recorder rec=new Recorder.Builder().setQualitySelector(QualitySelector.fromOrderedList(Arrays.asList(Quality.FHD,Quality.HD))).build();videoCapture=VideoCapture.withOutput(rec);cameraProvider.bindToLifecycle(this,sel,p,imageCapture,videoCapture);}
    private void takePhoto(){if(imageCapture==null)return;String name="FilmFilter_"+stamp()+".jpg";ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/FilmFilter");ImageCapture.OutputFileOptions o=new ImageCapture.OutputFileOptions.Builder(getContentResolver(),MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v).build();imageCapture.takePicture(o,ContextCompat.getMainExecutor(this),new ImageCapture.OnImageSavedCallback(){public void onImageSaved(ImageCapture.OutputFileResults r){Uri u=r.getSavedUri();if(u!=null) editImage(u);}public void onError(ImageCaptureException e){toast("사진 저장 실패");}});}
    private void toggleVideo(){if(!recording)startVideo();else stopVideo();}
    private void startVideo(){if(videoCapture==null)return;String name="FilmFilter_"+stamp()+".mp4";ContentValues v=new ContentValues();v.put(MediaStore.Video.Media.DISPLAY_NAME,name);v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");v.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/FilmFilter");PendingRecording p=videoCapture.getOutput().prepareRecording(this,new MediaStoreOutputOptions.Builder(getContentResolver(),MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(v).build()).withAudioEnabled();activeRecording=p.start(ContextCompat.getMainExecutor(this),e->{if(e instanceof VideoRecordEvent.Start){recording=true;shutter.setText("■");timer.setVisibility(View.VISIBLE);recordStart=SystemClock.elapsedRealtime();timer.post(clock);}if(e instanceof VideoRecordEvent.Finalize){recording=false;shutter.setText("●");timer.setVisibility(View.GONE);VideoRecordEvent.Finalize fin=(VideoRecordEvent.Finalize)e;if(fin.hasError())toast("원본 영상은 남았지만 녹화 오류가 발생했습니다");else toast("영상 저장 완료");}});}
    private void stopVideo(){if(activeRecording!=null){activeRecording.stop();activeRecording=null;}}
    private String stamp(){return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());}
    private void openGalleryImage(Uri u){if(u!=null)editImage(u);}
    private void editImage(Uri uri){io.execute(()->{try(InputStream in=getContentResolver().openInputStream(uri)){Bitmap src=BitmapFactory.decodeStream(in);runOnUiThread(()->showEditor(src));}catch(Exception e){runOnUiThread(()->toast("사진을 불러올 수 없습니다"));}});}
    private void showEditor(Bitmap src){final Bitmap original=src;ImageView image=new ImageView(this);image.setImageBitmap(original);image.setScaleType(ImageView.ScaleType.FIT_CENTER);FrameLayout editor=new FrameLayout(this);editor.setBackgroundColor(Color.BLACK);editor.addView(image,new FrameLayout.LayoutParams(-1,-1));LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(20,20,20,30);panel.setBackgroundColor(Color.argb(185,20,20,20));TextView title=label("KODAK · 길게 누르면 원본",14);panel.addView(title);Button save=glassButton("저장");panel.addView(save,new LinearLayout.LayoutParams(-1,55));FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,180,Gravity.BOTTOM);editor.addView(panel,pp);setContentView(editor);Runnable render=()->io.execute(()->{Bitmap out=FilmFilterEngine.apply(original,presets[presetIndex],filterStrength,brightness,temperature,grain,haze);runOnUiThread(()->image.setImageBitmap(out));});render.run();image.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN)image.setImageBitmap(original);if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL)render.run();return true;});save.setOnClickListener(v->io.execute(()->{Bitmap out=FilmFilterEngine.apply(original,presets[presetIndex],filterStrength,brightness,temperature,grain,haze);saveBitmap(out);runOnUiThread(()->{toast("고화질 저장 완료");buildUi();startCamera();});}));}
    private void saveBitmap(Bitmap b){String name="FilmFilter_EDIT_"+stamp()+".jpg";ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/FilmFilter");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)return;try(OutputStream o=getContentResolver().openOutputStream(u)){b.compress(Bitmap.CompressFormat.JPEG,97,o);}catch(Exception ignored){}}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    @Override protected void onDestroy(){super.onDestroy();if(activeRecording!=null)activeRecording.stop();io.shutdown();}
}
