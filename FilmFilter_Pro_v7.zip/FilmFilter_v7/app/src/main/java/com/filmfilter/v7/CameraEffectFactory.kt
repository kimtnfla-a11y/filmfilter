package com.filmfilter.v7

import kotlin.math.abs
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.camera.core.CameraEffect
import androidx.camera.media3.effect.Media3Effect
import androidx.media3.effect.Brightness
import androidx.media3.effect.GaussianBlurWithFrameOverlaid
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.SingleColorLut
import androidx.media3.common.util.UnstableApi
import java.util.concurrent.ExecutorService
import kotlin.random.Random

@OptIn(UnstableApi::class)
object CameraEffectFactory {
    fun create(context: Context, executor: ExecutorService, profile: FilterEngine.Profile, a: FilterEngine.Adjustments, onError: (Throwable)->Unit): Media3Effect {
        val effect = Media3Effect(context, CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE or CameraEffect.IMAGE_CAPTURE, executor) { onError(it) }
        update(effect, context, profile, a)
        return effect
    }

    fun update(effect: Media3Effect, context: Context, profile: FilterEngine.Profile, a: FilterEngine.Adjustments) {
        val list = mutableListOf<androidx.media3.common.Effect>()
        list += SingleColorLut.createFromCube(FilterEngine.lut(profile, a, 17))
        if (abs(a.brightness) > .001f) list += Brightness((a.brightness * .22f).coerceIn(-1f,1f))
        if (profile.haze * a.haze > .16f) list += GaussianBlurWithFrameOverlaid(1.15f, 1f, 1f)
        if (profile.grain * a.grain > .01f) {
            list += OverlayEffect(listOf(BitmapOverlay.createStaticBitmapOverlay(noiseBitmap(256, profile.grain * a.grain))))
        }
        effect.setEffects(list)
    }

    private fun noiseBitmap(size:Int, strength:Float): Bitmap {
        val b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888); val c=Canvas(b); val p=Paint(); val r=Random(77)
        repeat(size*size/2){ val v=if(r.nextBoolean()) 255 else 0; p.color=android.graphics.Color.argb((10+35*strength).toInt().coerceIn(3,28),v,v,v); c.drawPoint(r.nextInt(size).toFloat(),r.nextInt(size).toFloat(),p) }
        return b
    }
}
