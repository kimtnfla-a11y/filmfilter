package com.filmfilter.v7

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class EditActivity:AppCompatActivity(){
    private lateinit var image:ImageView; private lateinit var original:android.graphics.Bitmap; private var current:android.graphics.Bitmap?=null
    private var profile=FilterEngine.profiles[2]; private val adj=FilterEngine.Adjustments(); private val worker=Executors.newSingleThreadExecutor()
    override fun onCreate(b:Bundle?){super.onCreate(b); val uri=android.net.Uri.parse(intent.getStringExtra("uri")); original=contentResolver.openInputStream(uri)!!.use{BitmapFactory.decodeStream(it)}; build()}
    private fun build(){ val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(0xFF111111.toInt())}; image=ImageView(this).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setImageBitmap(original);setOnTouchListener{_,e->when(e.action){MotionEvent.ACTION_DOWN->{setImageBitmap(original);true};MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{setImageBitmap(current?:original);true};else->true}}};root.addView(image,LinearLayout.LayoutParams(-1,0,1f))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}; val sv=ScrollView(this); val chips=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; FilterEngine.profiles.forEach{p->val bt=Button(this);bt.text=p.name;bt.textSize=10f;bt.setOnClickListener{profile=p;render()};chips.addView(bt,LinearLayout.LayoutParams(90,50))};sv.addView(chips);row.addView(sv,LinearLayout.LayoutParams(0,58,1f));root.addView(row)
        root.addView(control("FILTER",0f,1f){adj.filterStrength=it;render()});root.addView(control("BRIGHTNESS",-1f,1f){adj.brightness=it*.8f;render()});root.addView(control("TEMPERATURE",-1f,1f){adj.temperature=it;render()});root.addView(control("GRAIN",0f,1f){adj.grain=it;render()});root.addView(control("HAZE",0f,1f){adj.haze=it;render()})
        val save=Button(this).apply{text="SAVE HIGH QUALITY";setOnClickListener{save()}};root.addView(save,LinearLayout.LayoutParams(-1,62));setContentView(root);render() }
    private fun control(name:String,min:Float,max:Float,fn:(Float)->Unit):SeekBar{val s=SeekBar(this);s.max=1000;s.progress=((0f-min)/(max-min)*1000).toInt();s.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(b:SeekBar?,p:Int,f:Boolean){if(f)fn(min+(max-min)*p/1000f)};override fun onStartTrackingTouch(b:SeekBar?){ };override fun onStopTrackingTouch(b:SeekBar?){ }});return s}
    private fun render(){val p=profile;val a=adj;worker.execute{val out=FilterEngine.apply(original,p,a,false);current=out;runOnUiThread{image.setImageBitmap(out)}}}
    private fun save(){val bmp=current?:return;val v=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"FilmFilter_Edit_${System.currentTimeMillis()}.jpg");put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/FilmFilter")};val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v)?:return;contentResolver.openOutputStream(uri)?.use{bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG,100,it)};Toast.makeText(this,"저장 완료",Toast.LENGTH_SHORT).show()}
    override fun onDestroy(){worker.shutdown();super.onDestroy()}
}
