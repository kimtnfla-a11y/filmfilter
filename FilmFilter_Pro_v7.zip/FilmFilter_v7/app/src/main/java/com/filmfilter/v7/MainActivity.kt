package com.filmfilter.v7

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraEffect
import androidx.camera.core.CameraSelector
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.camera.video.AudioConfig
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.media3.common.util.UnstableApi
import com.google.android.material.slider.Slider
import java.util.concurrent.Executors

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var controller: LifecycleCameraController
    private lateinit var effect: androidx.camera.media3.effect.Media3Effect
    private val executor = Executors.newSingleThreadExecutor()
    private var profileIndex = 2
    private var adjustments = FilterEngine.Adjustments()
    private var recording: Recording? = null
    private var modeVideo = false
    private var startedAt = 0L
    private lateinit var timer: TextView
    private lateinit var modeText: TextView

    private val permission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { if (it[Manifest.permission.CAMERA] == true) startCamera() }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi(); if (hasPermissions()) startCamera() else permission.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) }

    private fun buildUi() {
        val root=FrameLayout(this); preview=PreviewView(this); preview.implementationMode=PreviewView.ImplementationMode.PERFORMANCE; root.addView(preview, FrameLayout.LayoutParams(-1,-1))
        val top=LinearLayout(this); top.orientation=LinearLayout.HORIZONTAL; top.gravity=Gravity.CENTER_VERTICAL; top.setPadding(18,18,18,10)
        root.addView(top, FrameLayout.LayoutParams(-1,70,Gravity.TOP))
        val flip=button("↻"); flip.setOnClickListener { controller.cameraSelector=if(controller.cameraSelector==CameraSelector.DEFAULT_BACK_CAMERA) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA }; top.addView(flip, lp(56,56))
        modeText=label("PHOTO"); top.addView(modeText,lp(0,56,1f))
        val flash=button("⚡"); flash.setOnClickListener { cycleFlash(flash) }; top.addView(flash,lp(56,56))
        timer=label("00:00"); timer.visibility=View.GONE; top.addView(timer,lp(72,56))

        val bottom=LinearLayout(this); bottom.orientation=LinearLayout.VERTICAL; bottom.setPadding(18,8,18,18); root.addView(bottom,FrameLayout.LayoutParams(-1,320,Gravity.BOTTOM))
        val filters=HorizontalScrollView(this); val row=LinearLayout(this); row.orientation=LinearLayout.HORIZONTAL
        FilterEngine.profiles.forEachIndexed { i,p -> val b=button(p.name); b.textSize=11f; b.setOnClickListener { profileIndex=i; refreshEffect() }; row.addView(b,lp(92,52)) }; filters.addView(row); bottom.addView(filters,LinearLayout.LayoutParams(-1,58))
        val controls=LinearLayout(this); controls.orientation=LinearLayout.VERTICAL
        controls.addView(slider("FILTER",0f,1f,1f){ adjustments.filterStrength=it; refreshEffect() }); controls.addView(slider("BRIGHTNESS",-1f,1f,0f){ adjustments.brightness=it*0.8f; refreshEffect() }); controls.addView(slider("TEMPERATURE",-1f,1f,0f){ adjustments.temperature=it; refreshEffect() }); controls.addView(slider("GRAIN",0f,1f,adjustments.grain){ adjustments.grain=it; refreshEffect() }); controls.addView(slider("HAZE",0f,1f,adjustments.haze){ adjustments.haze=it; refreshEffect() }); bottom.addView(controls,LinearLayout.LayoutParams(-1,190))
        val actions=LinearLayout(this); actions.gravity=Gravity.CENTER; val gallery=button("▧"); gallery.setOnClickListener{openGallery()}; actions.addView(gallery,lp(60,60)); val shoot=button("●"); shoot.textSize=30f; shoot.setOnClickListener{capture()}; actions.addView(shoot,lp(86,70)); val mode=button("PHOTO / VIDEO"); mode.setOnClickListener{toggleMode()}; actions.addView(mode,lp(130,60)); bottom.addView(actions,LinearLayout.LayoutParams(-1,72))
        setContentView(root)
    }

    private fun slider(name:String,min:Float,max:Float,value:Float,onChange:(Float)->Unit):View { val box=LinearLayout(this); box.orientation=LinearLayout.HORIZONTAL; val t=label(name); t.textSize=10f; box.addView(t,lp(82,38)); val s=SeekBar(this); s.max=1000; s.progress=((value-min)/(max-min)*1000).toInt().coerceIn(0,1000); s.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(b:SeekBar?,p:Int,from:Boolean){if(from)onChange(min+(max-min)*p/1000f)};override fun onStartTrackingTouch(b:SeekBar?){};override fun onStopTrackingTouch(b:SeekBar?) {}}); box.addView(s,lp(0,38,1f)); return box }
    private fun button(s:String)=Button(this).apply{ text=s; setAllCaps(false); alpha=.9f; setPadding(2,0,2,0) }
    private fun label(s:String)=TextView(this).apply{ text=s; textSize=12f; setTextColor(0xFFFFFFFF.toInt()); gravity=Gravity.CENTER; setShadowLayer(8f,0f,2f,0xAA000000.toInt()) }
    private fun lp(w:Int,h:Int,weight:Float=0f)=LinearLayout.LayoutParams(if(weight>0)0:w,h,weight)
    private fun hasPermissions()=ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED

    private fun startCamera(){
        controller=LifecycleCameraController(this); controller.bindToLifecycle(this); controller.setEnabledUseCases(LifecycleCameraController.IMAGE_CAPTURE or LifecycleCameraController.VIDEO_CAPTURE); controller.setVideoCaptureTargetFrameRate(30..30); preview.controller=controller
        effect=CameraEffectFactory.create(this,executor,FilterEngine.profiles[profileIndex],adjustments){ runOnUiThread { Toast.makeText(this,"필터 처리 오류 — 카메라는 계속 유지됩니다",Toast.LENGTH_SHORT).show(); controller.clearEffects() } }; controller.setEffects(mutableSetOf(effect))
    }
    private fun refreshEffect(){ if(::effect.isInitialized){ try{CameraEffectFactory.update(effect,this,FilterEngine.profiles[profileIndex],adjustments)}catch(_:Throwable){}} }
    private fun cycleFlash(b:Button){ val next=when(controller.imageCaptureFlashMode){0->1;1->2;else->0}; controller.imageCaptureFlashMode=next; b.text=when(next){0->"⚡A";1->"⚡ON";else->"⚡OFF"} }
    private fun toggleMode(){ modeVideo=!modeVideo; modeText.text=if(modeVideo)"VIDEO" else "PHOTO"; timer.visibility=if(modeVideo)View.VISIBLE else View.GONE }
    private fun capture(){ if(modeVideo) recordVideo() else takePhoto() }
    private fun takePhoto(){ val name="FilmFilter_${System.currentTimeMillis()}.jpg"; val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/FilmFilter")}; val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values) ?: return; val out=androidx.camera.core.ImageCapture.OutputFileOptions.Builder(contentResolver.openOutputStream(uri)!!).build(); controller.takePicture(out,executor,object:androidx.camera.core.ImageCapture.OnImageSavedCallback{override fun onImageSaved(r:androidx.camera.core.ImageCapture.OutputFileResults){runOnUiThread{Toast.makeText(this@MainActivity,"저장 완료",Toast.LENGTH_SHORT).show()}};override fun onError(e:androidx.camera.core.ImageCaptureException){contentResolver.delete(uri,null,null);runOnUiThread{Toast.makeText(this@MainActivity,"사진 저장 실패",Toast.LENGTH_SHORT).show()}}}) }
    private fun recordVideo(){ if(recording!=null){recording?.stop(); return}; val name="FilmFilter_${System.currentTimeMillis()}.mp4"; val values=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,name);put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/FilmFilter")}; val opts=MediaStoreOutputOptions.Builder(contentResolver,MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build(); startedAt=SystemClock.elapsedRealtime(); timer.text="00:00"; recording=controller.startRecording(opts,AudioConfig.create(true),ContextCompat.getMainExecutor(this)){ e->when(e){is VideoRecordEvent.Start->runOnUiThread{modeText.text="REC";tickTimer()};is VideoRecordEvent.Status->{};is VideoRecordEvent.Finalize->runOnUiThread{recording=null;modeText.text="VIDEO";timer.text="00:00"; if(e.error!=VideoRecordEvent.Finalize.ERROR_NONE) Toast.makeText(this,"원본 영상은 저장 과정에서 보존됩니다",Toast.LENGTH_LONG).show()}}} }
    private fun tickTimer(){ if(recording==null)return; val sec=(SystemClock.elapsedRealtime()-startedAt)/1000; timer.text=String.format("%02d:%02d",sec/60,sec%60); timer.postDelayed({tickTimer()},500) }
    private fun openGallery(){ val i=Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply{type="image/*"}; startActivityForResult(i,1001) }
    @Deprecated("legacy callback") override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req==1001&&res==RESULT_OK&&data?.data!=null)startActivity(Intent(this,EditActivity::class.java).putExtra("uri",data.data.toString()))}
    override fun onDestroy(){recording?.stop();executor.shutdown();if(::effect.isInitialized)effect.close();super.onDestroy()}
}
