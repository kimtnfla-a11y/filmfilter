package com.filmfilter.v7

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

/** Shared film-grade engine. The same profiles feed CameraX/Media3 GPU LUTs and gallery export. */
object FilterEngine {
    data class Profile(val name: String, val warm: Float, val tint: Float, val sat: Float, val contrast: Float, val fade: Float, val shadow: Float, val highlight: Float, val grain: Float, val haze: Float, val halation: Float)
    data class Adjustments(var filterStrength: Float = 1f, var brightness: Float = 0f, var temperature: Float = 0f, var grain: Float = 0.35f, var haze: Float = 0.12f)

    val profiles = listOf(
        Profile("SPRING", .10f, .01f, 1.06f, 1.02f, .08f, .05f, -.02f, .28f, .08f, .08f),
        Profile("SUMMER", .16f, -.01f, 1.03f, .98f, .11f, .06f, -.05f, .25f, .12f, .10f),
        Profile("AUTUMN", .28f, .02f, 1.04f, 1.04f, .14f, .07f, -.04f, .32f, .10f, .18f),
        Profile("WINTER", -.10f, .00f, .92f, 1.08f, .06f, .02f, -.02f, .24f, .07f, .04f),
        Profile("TREE", .02f, .01f, .96f, 1.07f, .10f, .10f, -.04f, .34f, .06f, .05f),
        Profile("SEA", -.02f, -.04f, .95f, 1.00f, .12f, .04f, -.06f, .24f, .11f, .03f),
        Profile("FLOWER", .12f, .03f, 1.10f, 1.01f, .09f, .05f, -.03f, .30f, .09f, .12f),
        Profile("SUNSET", .34f, .025f, 1.07f, 1.03f, .16f, .08f, -.06f, .35f, .12f, .25f),
        Profile("CAFE", .22f, .015f, .98f, 1.08f, .17f, .12f, -.07f, .36f, .10f, .20f),
        Profile("FOOD", .18f, .01f, 1.08f, 1.02f, .10f, .05f, -.03f, .26f, .06f, .12f),
        Profile("STREET", .05f, -.01f, .94f, 1.12f, .13f, .13f, -.08f, .38f, .08f, .08f),
        Profile("NIGHT", .04f, -.025f, .90f, 1.10f, .09f, .16f, -.05f, .40f, .07f, .10f)
    )

    fun apply(bitmap: Bitmap, profile: Profile, a: Adjustments, preview: Boolean = false): Bitmap {
        val src = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        val seed = 0x9E3779B9
        for (i in px.indices) {
            val c = px[i]
            val graded = grade(Color.red(c)/255f, Color.green(c)/255f, Color.blue(c)/255f, profile, a)
            var r=graded[0]; var g=graded[1]; var b=graded[2]
            if (!preview) { val n = deterministicNoise(i, seed) * (profile.grain * a.grain) * .045f; r += n; g += n*.94f; b += n*.88f }
            px[i] = Color.argb(255, clamp(r*255f), clamp(g*255f), clamp(b*255f))
        }
        src.setPixels(px, 0, w, 0, 0, w, h)
        return src
    }

    fun skinWeight(r: Float, g: Float, b: Float): Float {
        val mx=max(r,max(g,b)); val mn=min(r,min(g,b)); val d=mx-mn
        if (d < .04f || r < g*1.03f || g < b*1.05f) return 0f
        val hue = when (mx) { r -> ((g-b)/d).let { if(it<0) it+6 else it } / 6f; g -> ((b-r)/d+2)/6f; else -> ((r-g)/d+4)/6f }
        val sat=d/mx.coerceAtLeast(.001f)
        val inHue = hue < .13f || hue > .98f
        return if (inHue && sat in .12f.. .72f && r > .28f) (1f-abs(hue-.055f)/.12f).coerceIn(0f,1f) else 0f
    }

    private fun filmTone(x0: Float, contrast: Float, fade: Float, shadow: Float, highlight: Float): Float {
        var x=x0.coerceIn(0f,1f)
        x = (x-.5f)*contrast+.5f
        x = x*(1f-fade)+fade*.045f
        x += shadow * (1f-x)*.13f
        x -= (-highlight).coerceAtLeast(0f) * smoothstep(.72f,1f,x)*.08f
        return x.coerceIn(0f,1f)
    }
    private fun smoothstep(a:Float,b:Float,x:Float):Float { val t=((x-a)/(b-a)).coerceIn(0f,1f); return t*t*(3f-2f*t) }
    private fun lerp(a:Float,b:Float,t:Float)=a+(b-a)*t
    private fun clamp(v:Float)= (v*1f).roundToInt().coerceIn(0,255)
    private fun deterministicNoise(i:Int, seed:Int):Float { var x=i xor seed; x = x*1664525+1013904223; return (((x ushr 8) and 0xFFFF)/32767.5f)-1f }

    private fun grade(r0:Float,g0:Float,b0:Float, profile:Profile, a:Adjustments):FloatArray {
        var r=r0; var g=g0; var b=b0
        val l=(r+g+b)/3f; val skin=skinWeight(r,g,b); val exposure=a.brightness*.22f
        r+=exposure; g+=exposure; b+=exposure
        val t=profile.warm+a.temperature*.22f; r+=t*.055f; b-=t*.045f; g+=profile.tint*.025f
        r=filmTone(r,profile.contrast,profile.fade,profile.shadow,profile.highlight); g=filmTone(g,profile.contrast,profile.fade,profile.shadow,profile.highlight); b=filmTone(b,profile.contrast,profile.fade,profile.shadow,profile.highlight)
        val lum=r*.2126f+g*.7152f+b*.0722f; r=lum+(r-lum)*profile.sat; g=lum+(g-lum)*profile.sat; b=lum+(b-lum)*profile.sat
        val hal=profile.halation*smoothstep(.68f,1f,l); r+=hal*.035f; g+=hal*.010f; b-=hal*.008f
        val protect=skin*.72f; r=lerp(r,r0+exposure*.25f,protect); g=lerp(g,g0+exposure*.25f,protect); b=lerp(b,b0+exposure*.25f,protect)
        val haze=(profile.haze*a.haze).coerceIn(0f,.35f); r=lerp(r,r*.92f+.08f,haze); g=lerp(g,g*.92f+.08f,haze); b=lerp(b,b*.92f+.08f,haze)
        val fs=a.filterStrength.coerceIn(0f,1f); r=lerp(r,r0,1f-fs); g=lerp(g,g0,1f-fs); b=lerp(b,b0,1f-fs)
        return floatArrayOf(r.coerceIn(0f,1f),g.coerceIn(0f,1f),b.coerceIn(0f,1f))
    }

    fun lut(profile: Profile, a: Adjustments, n: Int = 17): Array<Array<IntArray>> = Array(n) { z -> Array(n) { y -> IntArray(n) { x ->
        val out=grade(x/(n-1f),y/(n-1f),z/(n-1f),profile,a); Color.rgb(clamp(out[0]*255),clamp(out[1]*255),clamp(out[2]*255))
    } } }
}
