package com.filmfilter.v8

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.random.Random

/**
 * Lightweight GPU-friendly overlay used for the preview-only film texture.
 * The actual colour transform is applied directly to PreviewView by MainActivity.
 */
class FilterOverlayView(context: Context) : View(context) {
    var filterStrength = 0.70f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }
    var brightness = 0f
        set(value) { field = value.coerceIn(-1f, 1f); invalidate() }
    var temperature = 0f
        set(value) { field = value.coerceIn(-1f, 1f); invalidate() }
    var grain = 0.18f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }
    var haze = 0.10f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val random = Random(20260929)
    private val rect = RectF()

    init {
        setWillNotDraw(false)
        isClickable = false
        isFocusable = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Very subtle haze: not a solid white "fog" overlay.
        if (haze > 0.001f) {
            paint.style = Paint.Style.FILL
            paint.color = android.graphics.Color.argb(
                (haze * 18f).toInt().coerceIn(0, 24),
                232, 224, 208
            )
            rect.set(0f, 0f, width.toFloat(), height.toFloat())
            canvas.drawRect(rect, paint)
        }

        // Sparse luminance grain. This is deliberately subtle and does not tint pixels.
        if (grain > 0.001f && width > 0 && height > 0) {
            val count = ((width * height) / 18000f * grain)
                .toInt()
                .coerceIn(40, 1600)
            for (i in 0 until count) {
                val x = random.nextFloat() * width
                val y = random.nextFloat() * height
                val light = random.nextBoolean()
                val alpha = (grain * if (light) 18f else 14f).toInt().coerceIn(2, 20)
                paint.color = if (light) {
                    android.graphics.Color.argb(alpha, 255, 255, 255)
                } else {
                    android.graphics.Color.argb(alpha, 0, 0, 0)
                }
                canvas.drawRect(x, y, x + 1.1f, y + 1.1f, paint)
            }
        }
    }
}
